package com.etoak.crawl.link;

public interface LinkFilter {
    public boolean accept(String url);
}
