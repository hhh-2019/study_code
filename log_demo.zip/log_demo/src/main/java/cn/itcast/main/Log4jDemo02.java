package cn.itcast.main;

import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Slf4j
public class Log4jDemo02 {

    //private static Logger log = LoggerFactory.getLogger(Log4jDemo02.class);

    public static void main(String[] args) {

        log.trace("message1.....");
        log.debug("message2.....");
        log.info("message3.....");
        log.warn("message4.....");
        log.error("message5.....");

    }

}
