package cn.itcast.main;

public class LogDemo01 {

    public static void main(String[] args) {

        System.out.println("message1 ....");
        System.out.println("message2 ....");
        System.out.println("message3 ....");
        System.out.println("message4 ....");
        System.out.println("message5 ....");

    }

}
